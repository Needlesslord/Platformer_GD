<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="Tiles_Sand_Mud_Ice_32" tilewidth="32" tileheight="32" tilecount="55" columns="11">
 <image source="../Assets/Tiles_Sand_Mud_Ice_32.png" width="352" height="160"/>
 <terraintypes>
  <terrain name="Plat_desert" tile="0"/>
  <terrain name="Plat_grass" tile="0"/>
  <terrain name="Plat_ice" tile="0"/>
  <terrain name="Void" tile="0"/>
 </terraintypes>
 <tile id="0" terrain="3,3,3,0"/>
 <tile id="1" terrain="3,3,0,0"/>
 <tile id="2" terrain="3,3,0,3"/>
 <tile id="4" terrain="3,3,3,1"/>
 <tile id="5" terrain="3,3,1,1"/>
 <tile id="6" terrain="3,3,1,3"/>
 <tile id="8" terrain="3,3,3,2"/>
 <tile id="9" terrain="3,3,2,2"/>
 <tile id="10" terrain="3,3,2,3"/>
 <tile id="11" terrain="3,0,3,0"/>
 <tile id="12" terrain="0,0,0,0"/>
 <tile id="13" terrain="0,3,0,3"/>
 <tile id="15" terrain="3,1,3,1"/>
 <tile id="16" terrain="1,1,1,1"/>
 <tile id="17" terrain="1,3,1,3"/>
 <tile id="19" terrain="3,2,3,2"/>
 <tile id="20" terrain="2,2,2,2"/>
 <tile id="21" terrain="2,3,2,3"/>
 <tile id="22" terrain="3,0,3,3"/>
 <tile id="23" terrain="0,0,3,3"/>
 <tile id="24" terrain="0,3,3,3"/>
 <tile id="26" terrain="3,1,3,3"/>
 <tile id="27" terrain="1,1,3,3"/>
 <tile id="28" terrain="1,3,3,3"/>
 <tile id="30" terrain="3,2,3,3"/>
 <tile id="31" terrain="2,2,3,3"/>
 <tile id="32" terrain="2,3,3,3"/>
 <tile id="46" terrain="3,3,3,3"/>
</tileset>
