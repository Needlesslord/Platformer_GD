<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="Terrain_32" tilewidth="32" tileheight="32" tilecount="242" columns="22">
 <image source="../Assets/Terrain_32.png" width="704" height="352"/>
 <terraintypes>
  <terrain name="Void" tile="0"/>
  <terrain name="Plat_wood" tile="0"/>
  <terrain name="Wood" tile="0"/>
  <terrain name="Stone" tile="0"/>
  <terrain name="Plant" tile="0"/>
 </terraintypes>
 <tile id="0" terrain="3,3,3,0"/>
 <tile id="1" terrain="3,3,0,0"/>
 <tile id="2" terrain="3,3,0,3"/>
 <tile id="16" terrain=",,,0"/>
 <tile id="17" terrain=",,0,0"/>
 <tile id="18" terrain=",,0,0"/>
 <tile id="19" terrain=",,0,0"/>
 <tile id="20" terrain=",,0,"/>
 <tile id="22" terrain="3,0,3,0"/>
 <tile id="23" terrain="0,0,0,0"/>
 <tile id="24" terrain="0,3,0,3"/>
 <tile id="38" terrain=",0,,0"/>
 <tile id="39" terrain="1,1,0,0"/>
 <tile id="40" terrain="1,1,0,0"/>
 <tile id="41" terrain="1,1,0,0"/>
 <tile id="42" terrain="0,,0,"/>
 <tile id="44" terrain="3,0,3,3"/>
 <tile id="45" terrain="0,0,3,3"/>
 <tile id="46" terrain="0,3,3,3"/>
 <tile id="88" terrain="2,2,2,0"/>
 <tile id="89" terrain="2,2,0,0"/>
 <tile id="90" terrain="2,2,0,2"/>
 <tile id="110" terrain="2,0,2,0"/>
 <tile id="111" terrain="0,0,0,0"/>
 <tile id="112" terrain="0,2,0,2"/>
 <tile id="132" terrain="2,0,2,2"/>
 <tile id="133" terrain="0,0,2,2"/>
 <tile id="134" terrain="0,2,2,2"/>
 <tile id="176" terrain="4,4,4,0"/>
 <tile id="177" terrain="4,4,0,0"/>
 <tile id="178" terrain="4,4,0,4"/>
 <tile id="198" terrain="4,0,4,0"/>
 <tile id="199" terrain="0,0,0,0"/>
 <tile id="200" terrain="0,4,0,4"/>
 <tile id="220" terrain="4,0,4,4"/>
 <tile id="221" terrain="0,0,4,4"/>
 <tile id="222" terrain="0,4,4,4"/>
</tileset>
