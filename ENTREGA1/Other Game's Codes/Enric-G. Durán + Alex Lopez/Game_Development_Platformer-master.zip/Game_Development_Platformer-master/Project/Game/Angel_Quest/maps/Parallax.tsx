<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="Parallax" tilewidth="1140" tileheight="1000" tilecount="9" columns="3">
 <image source="Parallax.png" width="3420" height="3000"/>
</tileset>
