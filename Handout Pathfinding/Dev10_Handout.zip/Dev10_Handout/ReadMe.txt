R 			Reset Path

Space			Propagate BFS
M (Hold)  		Propagate BFS

J			Propagate Dijkstra
K (Hold)		Propagate Dijkstra

1			Propagate A* (Manhattan)
Shift + 1 (Hold)	Propagate A* (Manhattan)

2			Propagate A* (Squared)
Shift + 2 (Hold)	Propagate A* (Squared)

3			Propagate A* (Distance)
Shift + 3 (Hold)	Propagate A* (Distance)


--------------------------------------------------

Left mouse button used for BFS + Dijkstra

Right mouse button used for A*